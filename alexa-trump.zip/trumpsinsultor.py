from generator import generateInsult
from ask import alexa


def lambda_handler(request_obj, context=None):
    metadata = {'user_name' : 'SomeRandomDude'} # add your own metadata to the request using key value pairs
        return alexa.route_request(request_obj, metadata)

    @alexa.default
    def default_handler(request):
            """ The default handler gets invoked if no handler is set for a request type """
                return alexa.respond('Just ask').with_card('Hello World')


            @alexa.request("LaunchRequest")
            def launch_request_handler(request):
                    welcome = "Welcome to Trump Insult Generator.  You can generate an insult from Donald Trump's quotes by saying insult Brandon.  Lets get started."
                        return alexa.create_response(message=welcome)

                    @alexa.request("SessionEndedRequest")
                    def session_ended_request_handler(request):
                            return alexa.create_response(message="Goodbye!")


                        """
@alexa.intent('GetNewTrumpInsult')
def get_new_trump_insult(request):
    firstname = request.slots["firstname"]
    if firstname is None:
        return alexa.create_response("Could not find a firstname")
    insult = generateInsult(firstname)
    card = alexa.create_card(title="GetNewTrumpInsult", subtitle=None,content="asked alexa to get a new Trump insult")
    return alexa.create_response(insult,end_session=False,card_obj=card)
"""
                        
